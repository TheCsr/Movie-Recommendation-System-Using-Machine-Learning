import pandas as pd
import numpy as np
moviefrom = pd.read_csv('/home/thecsr/djangop/recmnd/moviesdata.csv', low_memory = False)
moviefrom['poster_path'] = moviefrom.poster_path.replace(np.NaN, '/6ksm1sjKMFLbO7UY2i6G1ju9SML.jpg')
moviefrom.to_csv('final.csv')