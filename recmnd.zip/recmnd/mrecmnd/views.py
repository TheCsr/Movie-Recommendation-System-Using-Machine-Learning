from django.contrib.auth.decorators import login_required
from django.shortcuts import render,redirect
from django.http import HttpResponse
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import login as auth_login, authenticate
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import linear_kernel
import pandas as pd
import itertools
from ast import literal_eval
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import numpy as np


from mrecmnd.models import movies





moviesdatasim = pd.read_csv('/home/thecsr/djangop/recmnd/moviesdata.csv', low_memory = False)
moviedata = pd.read_csv('/home/thecsr/djangop/recmnd/finalfinal.csv', low_memory=False)

def index(request):
    return render(request,"index.html")
def login(request):
    return render(request,"login.html")


def entry(request):
    if request.method=='POST':
        a=request.POST['movie']
        x=movies()
        x.movie=a
        x.save()
        return render(request,"index.html")


@login_required
def poke(request):
    v = movies.objects.all
    return render(request, 'index.html', {'d' : v})



def register(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data.get('username')
            raw_password = form.cleaned_data.get('password1')
            user = authenticate(username=username, password=raw_password)
            auth_login(request, user)
            return redirect('/home')
    else:
        form = UserCreationForm()
    return render(request,'registration/reg_form.html', {'form': form})


def simplerecommender(request):
    C = moviesdatasim['vote_average'].mean()
    m = moviesdatasim['vote_count'].quantile(0.25)

    q_movies = moviesdatasim.copy().loc[moviesdatasim['vote_count'] >= m]

    def weighted_rating(x, m=m, C=C):
        v = x['vote_count']
        R = x['vote_average']
        # Calculation based on the IMDB formula
        return (v / (v + m) * R) + (m / (m + v) * C)

    q_movies['score'] = q_movies.apply(weighted_rating, axis=1)

    q_movies = q_movies.sort_values('score', ascending=False)

    poster = q_movies['poster_path'].head(7)
    mtitle = q_movies['title'].head(7)
    posterpath = "http://image.tmdb.org/t/p/w154/"+poster
    dictionary = dict(itertools.izip(mtitle, posterpath))
    return dictionary
    #return render(request, 'index.html', {'sim' : dictionary})

def contentrec(request):
    if request.method == 'POST':
        b=[]
        c=[]
        vectorizer = TfidfVectorizer(stop_words='english')

    # Replace NaN with an empty string
        moviedata['overview'] = moviedata['overview'].fillna('')
    # Construct the required TF-IDF matrix by fitting and transforming the data

        tfidf_matrix = vectorizer.fit_transform(moviedata['overview'])

        cosine_sim = linear_kernel(tfidf_matrix, tfidf_matrix)

        indices = pd.Series(moviedata.index, index=moviedata['title']).drop_duplicates()

        def get_recommendations(title, cosine_sim=cosine_sim):
        # Get the index of the movie that matches the title
            idx = indices[title]

        # Get the pairwsie similarity scores of all movies with that movie
            sim_scores = list(enumerate(cosine_sim[idx]))

        # Sort the movies based on the similarity scores
            sim_scores = sorted(sim_scores, key=lambda x: x[1], reverse=True)

        # Get the scores of the 10 most similar movies
            sim_scores = sim_scores[1:8]

        # Get the movie indices
            movie_indices = [i[0] for i in sim_scores]
            zmovies =pd.Series.to_dict(moviedata['poster_path'].iloc[movie_indices])
            tmovies =pd.Series.to_dict(moviedata['title'].iloc[movie_indices])
            for ka,va in zmovies.items():
                link = "http://image.tmdb.org/t/p/w154/"+va
                b.append(link)
            for ka1,va1 in tmovies.items():
                c.append(va1)
            dictionary = dict(itertools.izip(c, b))
            return dictionary
        try:
            movie_name =request.POST["entermovie"]
            final=get_recommendations(movie_name)
            return final
            #return render(request, 'index.html', {'da' : final})

        except:
            message = "Movie Not Found in the database"
            return render(request,'index.html', {'msg' : message})



def genrebased(request):
    if request.method == 'POST' :
        moviedata = pd.read_csv('/home/thecsr/djangop/recmnd/finalfinal.csv', low_memory=False)
        b1 = []
        c1 = []

        # Parse the stringified features into their corresponding python objects

        features = ['cast', 'crew', 'keywords', 'genres']
        for feature in features:
            moviedata[feature] = moviedata[feature].apply(literal_eval)

        def get_director(x):
            for i in x:
                if i['job'] == 'Director':
                    return i['name']
            return np.nan

        # Returns the list top 3 elements or entire list; whichever is more.
        def get_list(x):
            if isinstance(x, list):
                names = [i['name'] for i in x]
                # Check if more than 3 elements exist. If yes, return only first three. If no, return entire list.
                if len(names) > 3:
                    names = names[:3]
                return names

            # Return empty list in case of missing/malformed data
            return []

        # Define new director, cast, genres and keywords features that are in a suitable form.
        moviedata['director'] = moviedata['crew'].apply(get_director)

        features = ['cast', 'keywords', 'genres']
        for feature in features:
            moviedata[feature] = moviedata[feature].apply(get_list)

        def clean_data(x):
            if isinstance(x, list):
                return [str.lower(i.replace(" ", "")) for i in x]
            else:
                # Check if director exists. If not, return empty string
                if isinstance(x, str):
                    return str.lower(x.replace(" ", ""))
                else:
                    return ''

        features = ['cast', 'keywords', 'director', 'genres']

        for feature in features:
            moviedata[feature] = moviedata[feature].apply(clean_data)

        # print(moviedata[['title', 'cast', 'director', 'keywords', 'genres']].head(3))
        def create_soup(x):
            return ' '.join(x['keywords']) + ' ' + ' '.join(x['cast']) + ' ' + x['director'] + ' ' + ' '.join(
                x['genres'])

        moviedata['soup'] = moviedata.apply(create_soup, axis=1)
        moviedata['soup'] = moviedata["soup"].apply(lambda x: ''.join([" " if ord(i) < 32 or ord(i) > 126 else i for i in x]))

        count = CountVectorizer(stop_words='english')
        count_matrix = count.fit_transform(moviedata['soup'])

        cosine_sim2 = cosine_similarity(count_matrix, count_matrix)

        moviedata = moviedata.reset_index()
        indices = pd.Series(moviedata.index, index=moviedata['title'])

        def get_recommendations1(title, cosine_sim=cosine_sim2):
            # Get the index of the movie that matches the title
            idx = indices[title]

            # Get the pairwsie similarity scores of all movies with that movie
            sim_scores = list(enumerate(cosine_sim[idx]))

            # Sort the movies based on the similarity scores
            sim_scores = sorted(sim_scores, key=lambda x: x[1], reverse=True)

            # Get the scores of the 10 most similar movies
            sim_scores = sim_scores[1:8]

            # Get the movie indices
            movie_indices = [i[0] for i in sim_scores]

            # Return the top 10 most similar movies
            movie_indices = [i[0] for i in sim_scores]
            zmovies1 = pd.Series.to_dict(moviedata['poster_path'].iloc[movie_indices])
            tmovies1 = pd.Series.to_dict(moviedata['title'].iloc[movie_indices])
            for ka11, va11 in zmovies1.items():
                link1 = "http://image.tmdb.org/t/p/w154/" + va11
                b1.append(link1)
            for ka12, va12 in tmovies1.items():
                c1.append(va12)
            dictionary1 = dict(itertools.izip(c1, b1))
            return dictionary1

        try:
            movie_name1 = request.POST["entermovie"]
            final1 = get_recommendations1(movie_name1)
            final = contentrec(request)
            simplerecc = simplerecommender(request)
            return render(request, 'index.html', {'da1': final1 , 'da':final , 'sim':simplerecc})
        except:
            message1 = "Movie Not Found in the database"
            return render(request, 'index.html', {'msg': message1})















