from django.contrib import admin

from .models import movies

admin.site.register(movies)
