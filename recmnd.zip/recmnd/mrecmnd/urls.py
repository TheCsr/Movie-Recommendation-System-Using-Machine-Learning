from django.conf.urls import url
from django.contrib.auth import views as auth_views

from . import views

urlpatterns = [
    url(r'^$', auth_views.login, name='login'),
    url(r'^logout/',auth_views.logout,{'next_page' : 'login'},name='logout'),
    url(r'^home/',views.index,name='index'),
    url(r'^details/',views.entry, name='details'),
    url(r'^simple/',views.simplerecommender, name='simplerec'),
    url(r'^contents/',views.contentrec, name = 'content'),
    url(r'^displays/',views.poke,name='display'),
    url(r'^register/', views.register, name='register'),
    url(r'^genre/',views.genrebased, name='genre'),

]